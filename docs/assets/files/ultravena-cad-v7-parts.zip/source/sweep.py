"""Range-of-motion clash sweep. Moves the six axes through their limits and reports every pair of parts that newly collides."""
import itertools, sys, time, math
import cadquery as cq
from ultravena_rig_v2 import build, P
EXPECT = ('float_guide_rod', 'float_stop_collar', 'screw', 'wheel_bolt', 'pulley', 'output_boss', 'spline', 'belt_strand', 'ball_joint', '_stem', 'bracket_arm', 'x_idler_axle', 'pitch_pin', 'roll_pin', 'limit_switch', 'horn', 'tip_holder')
LIM = dict(gy=(166, 56, -44), x=(-80, 0, 80), zdown=(0, 90), yaw=(-90, -45, 0, 45, 90), pitch=(-30, 0, 30), roll=(-20, 0, 20))
def run(v, lim=LIM, verbose=True):
    t0 = time.time(); A, flat, _, info = build(v, wiring=False); g = info['groups']; geo = info['geo']
    rot = lambda ax, deg: cq.Location((0, 0, 0), ax, deg)
    def set_pose(p):
        g['G'].loc = cq.Location((0, p['gy'], 0)); g['XC'].loc = cq.Location((p['x'], 0, 0)); g['ZS'].loc = cq.Location((0, 0, geo['zsZ'] - p['zdown']))
        g['YAW'].loc = cq.Location((0, geo['pd'], geo['yawz'])) * rot((0, 0, 1), p['yaw']); g['PIT'].loc = cq.Location((0, 0, -geo['up'])) * rot((1, 0, 0), p['pitch']); g['ROL'].loc = rot((0, 1, 0), p['roll'])
    lvl = {id(g[k]): i for i, k in enumerate(['G', 'XC', 'ZS', 'YAW', 'PIT', 'ROL'], start=1)}; lvl[id(g['FL'])] = 3
    ents = []
    for n, s, c, grp, loc in flat:
        bb = s.BoundingBox(); cor = [(x, y, z) for x in (bb.xmin, bb.xmax) for y in (bb.ymin, bb.ymax) for z in (bb.zmin, bb.zmax)]
        ents.append(dict(n=n, s=s, c=c, grp=grp, loc=loc, cor=cor, lv=lvl.get(id(grp), 0)))
    def aabb(e, w):
        pts = [(w * cq.Location(c)).toTuple()[0] for c in e['cor']]
        return [min(p[i] for p in pts) for i in range(3)] + [max(p[i] for p in pts) for i in range(3)]
    def hit(a, b): return not (a[3] < b[0] + 0.1 or b[3] < a[0] + 0.1 or a[4] < b[1] + 0.1 or b[4] < a[1] + 0.1 or a[5] < b[2] + 0.1 or b[5] < a[2] + 0.1)
    def overlaps(pose, pairs_filter):
        set_pose(pose); wl = {}; out = {}
        for e in ents:
            k = (id(e['grp']), id(e['loc']))
            e['w'] = e['grp'].world() * e['loc']; e['bb'] = aabb(e, e['w'])
        for a, b in itertools.combinations(ents, 2):
            if a['c'] == b['c'] or not pairs_filter(a, b) or not hit(a['bb'], b['bb']): continue
            if any(x in a['n'] or x in b['n'] for x in EXPECT): continue
            try: vol = a['s'].moved(a['w']).intersect(b['s'].moved(b['w'])).Volume()
            except Exception: vol = -1
            if vol > 2 or vol < 0: out[(a['n'], b['n'])] = vol
        return out
    base = overlaps(dict(gy=56, x=0, zdown=0, yaw=0, pitch=0, roll=0), lambda a, b: True)
    worst = {}
    def note(res, pose):
        for k, vol in res.items():
            if vol <= base.get(k, 0) + 2: continue
            if k not in worst or vol > worst[k][0]: worst[k] = (vol, dict(pose))
    # 1. the head against itself, the X carriage and the gantry: depends on Z travel and the three angles only
    n1 = 0
    for zd, yaw, pitch, roll in itertools.product(lim['zdown'], lim['yaw'], lim['pitch'], lim['roll']):
        pose = dict(gy=56, x=0, zdown=zd, yaw=yaw, pitch=pitch, roll=roll); n1 += 1
        note(overlaps(pose, lambda a, b: a['lv'] != b['lv'] and max(a['lv'], b['lv']) >= 3 and min(a['lv'], b['lv']) >= 1), pose)
    # 2. everything that moves against everything fixed: all six axes at their limits
    n2 = 0
    for gy, x, zd, yaw, pitch, roll in itertools.product(lim['gy'], lim['x'], lim['zdown'], (-90, 0, 90), lim['pitch'], lim['roll']):
        pose = dict(gy=gy, x=x, zdown=zd, yaw=yaw, pitch=pitch, roll=roll); n2 += 1
        note(overlaps(pose, lambda a, b: min(a['lv'], b['lv']) == 0 and max(a['lv'], b['lv']) >= 1), pose)
    # 3. the X carriage against the gantry across X travel
    for x in lim['x']:
        pose = dict(gy=56, x=x, zdown=0, yaw=0, pitch=0, roll=0); note(overlaps(pose, lambda a, b: {a['lv'], b['lv']} == {1, 2}), pose)
    print(v, ':', n1 + n2 + 3, 'poses,', len(worst), 'new collisions,', round(time.time() - t0), 's')
    for k, (vol, pose) in sorted(worst.items(), key=lambda q: -q[1][0]): print('   %8.0f mm3  %s  x  %s   at %s' % (vol, k[0], k[1], pose))
    return worst
if __name__ == '__main__':
    for v in sys.argv[1:]: run(v)
