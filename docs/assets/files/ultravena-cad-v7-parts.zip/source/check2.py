import itertools, sys, time
from ultravena_rig_v2 import build
EXPECT = ('float_guide_rod', 'float_stop_collar', 'tip_holder', 'screw', 'wheel_bolt', 'pulley', "spline", "output_boss", 'belt_strand', 'ball_joint', '_stem', 'bracket_arm', 'x_idler_axle', 'pitch_pin', 'roll_pin', 'limit_switch', 'horn')
for v in sys.argv[1:]:
    t0 = time.time(); A, flat, _, info = build(v, wiring=False)
    items = []
    for n, s, c, g, loc in flat:
        m = s.moved(g.world() * loc); items.append((n, m, m.BoundingBox(), c))
    hits = []; tested = 0
    for (na, a, ba, ca), (nb, b, bb, cb) in itertools.combinations(items, 2):
        if ca == cb: continue
        if ba.xmax < bb.xmin + 0.05 or bb.xmax < ba.xmin + 0.05 or ba.ymax < bb.ymin + 0.05 or bb.ymax < ba.ymin + 0.05 or ba.zmax < bb.zmin + 0.05 or bb.zmax < ba.zmin + 0.05: continue
        tested += 1
        try: vol = a.intersect(b).Volume()
        except Exception: vol = -1
        if vol > 1.5 or vol < 0: hits.append((round(vol, 1), na, nb))
    real = [h for h in hits if not any(e in h[1] or e in h[2] for e in EXPECT)]
    print(v, len(items), 'solids,', tested, 'pairs tested,', len(hits), 'overlaps of which', len(hits) - len(real), 'are intended fits,', round(time.time() - t0), 's')
    for h in sorted(real, reverse=True): print('  ', h)
