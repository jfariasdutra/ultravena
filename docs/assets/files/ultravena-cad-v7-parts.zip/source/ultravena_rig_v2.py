"""UltraVena tabletop rig, hardware only, detailed model with wiring. CadQuery, millimetres.
Axes: X across the arm, Y depth (user at -Y, back wall at +Y), Z up from the table top.
Run:  python3 ultravena_rig_v2.py [butterfly|vscan]   -> out2/*.step, out2/*.stl, out2/*.glb
Pose: gantry mid-travel, X centred, probe fully raised, yaw/pitch/roll at zero. Edit P to change the design."""
import math, sys, itertools
import cadquery as cq
from lib import *

P = dict(wallX=258, back=258, front=-300, top=590, mouth=200, hood_top_y=-190, panel=3, base_t=12,
         railX=185, beltX=207, beamZ=400, probe_dy=-116, pivot_up=55, face_z_raised=163, float_travel=15, stamp_gap=24,
         pass_x=-15, pass_z=235)
PROBES = {'butterfly': dict(name='Butterfly iQ3', L=152, w=52, t=37), 'vscan': dict(name='GE Vscan Extend dual probe', L=129, w=39, t=28)}
WR = dict(mains=2.2, v24=1.5, v12=1.3, v6=1.5, v5=1.2, usb=1.9, step=2.0, sig=1.0, probe=2.6, bus=1.8)


POSE0 = dict(gy=56, x=0, zdown=0, yaw=0, pitch=0, roll=0, float=0)     # gantry Y position, X offset, Z travel down from fully raised, then the three head angles in degrees

def build(variant='butterfly', wiring=True, pose=None):
    pose = dict(POSE0, **(pose or {}))
    pr = PROBES[variant]; Lp, w, t = pr['L'], pr['w'], pr['t']; isB = variant == 'butterfly'
    X, back, front, top, pt = P['wallX'], P['back'], P['front'], P['top'], P['panel']
    root = cq.Assembly(name='UltraVena_rig_' + variant); used = {}; flat = []; groups = []      # flat: (name, solid in world, component id) for the clash check
    def uniq(n):
        used[n] = used.get(n, 0) + 1; return n if used[n] == 1 else f'{n}_{used[n]}'
    class Grp:
        def __init__(s, name, parent=None, loc=None):
            s.loc = loc or cq.Location(); s.asm = cq.Assembly(name=uniq(name), loc=s.loc); s.parent = parent
            groups.append(s)
        def world(s): return (s.parent.world() * s.loc) if s.parent else s.loc
        def part(s, solid, name, col, loc=None):
            n = uniq(name); loc = loc or cq.Location(); s.asm.add(solid, name=n, color=cq.Color(*COL[col]), loc=loc)
            flat.append((n, solid.val(), n, s, loc)); return n
        def comp(s, parts, name, loc=None):
            n = uniq(name); loc = loc or cq.Location(); sub = cq.Assembly(name=n, loc=loc)
            for sol, pn, col in parts:
                sub.add(sol, name=f'{n}__{pn}', color=cq.Color(*COL[col])); flat.append((f'{n}__{pn}', sol.val(), n, s, loc))
            s.asm.add(sub); return n
        def W(s, x, y, z):                       # a point in this group's frame, in world coordinates
            return (s.world() * cq.Location((x, y, z))).toTuple()[0]
    def screws(g, d, ln, pts, z=(0, 0, 1), name='screw'):
        zx = (1, 0, 0) if abs(z[0]) < 0.9 else (0, 1, 0)
        for p in pts: g.part(shcs(d, ln), name, 'steel', L(p, zx, z))
    def standoffs(g, cx, cz, wx, hz, inset, y0, h, name):
        for sx in (-1, 1):
            for sz in (-1, 1): g.part(tube(2.6, 1.3, h, (cx + sx * (wx / 2 - inset), y0 + h / 2, cz + sz * (hz / 2 - inset)), 'Y'), name + '_standoff', 'brass')

    # ================= base =================
    B = Grp('base')
    depth = back - front + 4
    plate = box(2 * X, depth, P['base_t'], (0, (back + front) / 2, 6), 8, '|Z')
    B.part(plate, 'base_plate', 'plate')
    for sx, y in [(-1, front + 24), (1, front + 24), (-1, back - 22), (1, back - 22)]: B.part(cyl(14, 14, (sx * 232, y, -7)).faces('<Z').chamfer(2), 'rubber_foot', 'rubber')
    pad = box(120, 300, 18, (0, -90, 21), 3, '|Y').cut(cyl(70, 300, (0, -90, 92), 'Y')).cut(box(84, 300, 6, (0, -90, 25.05)))
    B.part(pad, 'arm_rest_pad', 'pad')
    for sx in (-1, 1): B.part(box(14, 300, 28, (sx * 67, -90, 26), 4), 'arm_rest_bolster', 'pad')
    B.part(box(116, 130, 24, (0, 125, 24), 4), 'hand_pad', 'pad')
    pad_xy = [(sx * 21, y) for y in (10, -90, -190) for sx in (-1, 1)]                     # two columns of three, so a rolling arm shifts weight between columns
    for px_, y in pad_xy: B.part(box(38, 38, 0.5, (px_, y, 22.3)), 'pressure_pad', 'gold')                 # 38 mm square sensing area (pub)
    B.part(cyl(13, 96, (0, 176, 60), 'X'), 'hand_grip', 'rubber')
    for sx in (-1, 1): B.part(box(8, 16, 26, (sx * 52, 176, 49)), 'hand_grip_post', 'printed')
    for sx in (-1, 1):
        B.part(extrusion(400), 'y_rail_2020', 'alu', L((sx * P['railX'], 0, 30), (1, 0, 0), (0, 1, 0)))
        for y in (-180, 0, 180): B.part(box(20, 20, 8, (sx * P['railX'], y, 16)), 'y_rail_support', 'steel')
        bx = sx * P['beltX']
        B.comp(nema17(40), 'y_stepper', L((bx, 224, 56)))
        mp = box(46, 46, 3, (bx, 224, 57.5)).cut(cyl(11.6, 10, (bx, 224, 57.5))).union(box(3, 44, 45.5, (bx - sx * 24.5, 225, 34.75)))
        for a in (-1, 1):
            for b in (-1, 1): mp = mp.cut(cyl(1.7, 10, (bx + a * 15.5, 224 + b * 15.5, 57.5)))
        B.part(mp, 'y_motor_mount', 'steel'); screws(B, 3, 8, [(bx + a * 15.5, 224 + b * 15.5, 59) for a in (-1, 1) for b in (-1, 1)])
        B.comp(gt2_pulley(), 'y_pulley', L((bx, 224, 67)))
        B.comp(idler(), 'y_idler', L((bx, -196, 67))); B.part(cyl(1.5, 62, (bx, -196, 43)).union(cyl(9, 4, (bx, -196, 14))).union(cyl(4, 46, (bx, -196, 39))), 'y_idler_post', 'steel')
        for o in (-6.5, 6.5): B.part(box(1.5, 420, 6, (bx + o, 14, 67)), 'y_belt_strand', 'rubber')
    B.comp(limit_switch(), 'limit_switch_y', L((-P['railX'], 193, 46), (0, 0, 1), (0, -1, 0)))

    # ================= enclosure =================
    E = Grp('enclosure'); fx, fyB, fyF = X - 14, back - 14, front + 12
    brk = lambda g, pos, x, z: g.comp([(corner_bracket(), 'bracket', 'alu'), (shcs(5, 8).translate((11, 0, 3)), 'screw_a', 'steel'), (shcs(5, 8).rotate((0, 0, 0), (0, 1, 0), 90).translate((3, 0, 11)), 'screw_b', 'steel')], 'corner_bracket', L(pos, x, z))
    for sx in (-1, 1):
        E.part(extrusion(top - 12), 'frame_post_back', 'alu', L((sx * fx, fyB, (top + 12) / 2)))
        E.part(extrusion(P['mouth'] - 26), 'frame_post_front', 'alu', L((sx * fx, fyF, (P['mouth'] - 14 + 12) / 2)))
        y0, y1 = P['hood_top_y'] + 26, fyB - 10
        E.part(extrusion(y1 - y0), 'frame_top_rail_side', 'alu', L((sx * fx, (y0 + y1) / 2, top - 10), (1, 0, 0), (0, 1, 0)))
        yl = y1 - y0 - 30; ylc = (y0 + y1 - 24) / 2
        E.part(box(12, yl, 5, (sx * fx, ylc, top - 22.5)).cut(box(10, yl, 3, (sx * fx, ylc, top - 24))), 'led_channel_side', 'alu')
        E.part(box(10, yl - 2, 2, (sx * fx, ylc, top - 23.6)), 'led_strip_side', 'led')
        brk(E, (sx * fx, fyB - 10, 12), (0, -1, 0), (0, 0, 1)); brk(E, (sx * (fx - 10), fyF, 12), (-sx, 0, 0), (0, 0, 1))
        brk(E, (sx * (fx - 10), fyB, top - 20), (-sx, 0, 0), (0, 0, -1)); brk(E, (sx * fx, fyB - 10, top - 20), (0, -1, 0), (0, 0, -1))
    E.part(extrusion(2 * fx - 20), 'frame_top_rail_back', 'alu', L((0, fyB, top - 10), (0, 1, 0), (1, 0, 0)))
    E.part(box(2 * fx - 68, 12, 5, (0, fyB, top - 22.5)).cut(box(2 * fx - 68, 10, 3, (0, fyB, top - 24))), 'led_channel_back', 'alu')
    E.part(box(2 * fx - 70, 10, 2, (0, fyB, top - 23.6)), 'led_strip_back', 'led')
    px0, pz0 = P['pass_x'], P['pass_z']
    bw = box(2 * X - 2 * pt, pt, top - 12, (0, back - pt / 2, (top + 12) / 2)).cut(cyl(17, 20, (px0, back - pt / 2, pz0), 'Y'))
    if not isB: bw = bw.cut(cyl(8, 20, (46, back - pt / 2, 100), 'Y'))
    bscr = [(sx * fx, back, z) for sx in (-1, 1) for z in (100, 170, 420, 480, 540)] + [(x, back, top - 10) for x in (-180, -60, 60, 180)]
    for p in bscr: bw = bw.cut(cyl(2.7, 20, (p[0], back - pt / 2, p[2]), 'Y'))
    E.part(bw, 'wall_back', 'panel'); screws(E, 5, 10, bscr, (0, 1, 0), 'panel_screw')
    E.part(tube(21, 15, 2, (px0, back + 1, pz0), 'Y').union(tube(21, 15, 2, (px0, back - pt - 1, pz0), 'Y')).union(tube(17, 15, pt, (px0, back - pt / 2, pz0), 'Y')), 'cable_pass_through', 'rubber')
    side = cq.Workplane('YZ').polyline([(back, 12), (front, 12), (front, P['mouth']), (P['hood_top_y'], top), (back, top)]).close().extrude(pt)
    for sx in (-1, 1):
        sscr = [(sx * X, fyB, z) for z in (60, 170, 280, 390, 500)] + [(sx * X, y, top - 10) for y in (-120, -10, 100, 200)] + [(sx * X, fyF, z) for z in (50, 130)]
        s2 = side.translate((X - pt if sx > 0 else -X, 0, 0))
        for p in sscr: s2 = s2.cut(cyl(2.7, 20, (sx * (X - pt / 2), p[1], p[2]), 'X'))
        E.part(s2, 'wall_side', 'panel'); screws(E, 5, 10, sscr, (sx, 0, 0), 'panel_screw')

    # slanted front panel. Hood frame: X across, Z up the slope from the lower edge, -Y is the outward face
    ha = math.atan2(front - P['hood_top_y'], top - P['mouth']); hl = math.hypot(front - P['hood_top_y'], top - P['mouth'])
    H = Grp('front_panel_assembly', E, cq.Location((0, front, P['mouth'])) * cq.Location((0, 0, 0), (1, 0, 0), math.degrees(ha)))
    ipx, ips = -10, 215; esx, esz = 215, 58; phx, phz = ipx + 97.7 + 24, ips      # iPad centre on the panel, stop button, probe cable hole
    hp = box(2 * X - 2 * pt, pt, hl, (0, pt / 2, hl / 2)).cut(cyl(11.2, 20, (esx, pt / 2, esz), 'Y'))
    if isB: hp = hp.cut(cyl(8, 20, (phx, pt / 2, phz), 'Y'))
    hscr = [(sx * fx, 0, s) for sx in (-1, 1) for s in (40, 120, 200, 280, 360)] + [(x, 0, s) for s in (10, hl - 10) for x in (-180, -60, 60, 180)]
    for p in hscr: hp = hp.cut(cyl(2.7, 20, (p[0], pt / 2, p[2]), 'Y'))
    H.part(hp, 'front_panel_slanted', 'panel'); screws(H, 5, 10, hscr, (0, -1, 0), 'panel_screw')
    for sx in (-1, 1): H.part(extrusion(hl), 'front_panel_rail', 'alu', L((sx * fx, pt + 10, hl / 2)))
    for s in (10, hl - 10): H.part(extrusion(2 * fx - 20), 'front_panel_cross_rail', 'alu', L((0, pt + 10, s), (0, 1, 0), (1, 0, 0)))
    H.part(box(2 * fx - 28, 5, 12, (0, pt + 22.5, 10)).cut(box(2 * fx - 28, 3, 10, (0, pt + 24, 10))), 'led_channel_front', 'alu'); H.part(box(2 * fx - 30, 2, 10, (0, pt + 23.6, 10)), 'led_strip_front', 'led')
    H.comp(estop(), 'emergency_stop', L((esx, 0, esz)))
    # iPad mini slot: a printed pocket on the outside of the panel, open at the top so the iPad lifts straight out for charging
    slot = box(206, 2, 126, (ipx, -1, ips - 6)).union(box(206, 8.7, 4, (ipx, -6.35, ips - 69.4))).union(box(206, 1.6, 8, (ipx, -9.9, ips - 65.4)))
    for sx in (-1, 1): slot = slot.union(box(4, 8.7, 110, (ipx + sx * 100.3, -6.35, ips - 12))).union(box(9, 1.6, 110, (ipx + sx * 97.8, -9.9, ips - 12)))
    slot = slot.cut(box(24, 30, 22, (ipx + 100, -8, ips)))                       # notch for the probe's USB-C plug
    sscr2 = [(ipx + a * 80, -2, ips - 6 + b * 50) for a in (-1, 1) for b in (-1, 1)]
    for q in sscr2: slot = slot.cut(cyl(1.7, 10, (q[0], -1, q[2]), 'Y'))
    ipad_slot = slot; H.part(slot, 'printed_ipad_slot', 'printed'); screws(H, 3, 8, sscr2, (0, -1, 0)); H.comp(ipad_mini(), 'ipad_mini', L((ipx, -5.55, ips)))
    if isB: H.comp(grommet(), 'probe_cable_grommet', L((phx, pt / 2, phz), (1, 0, 0), (0, 1, 0)))

    # two webcams on printed wall brackets: one high for the overview the user taps on, one low that sees under the bridge
    def camera(name, pos, target, wall_pt, wall_n):
        f = (cq.Vector(*target) - cq.Vector(*pos)).normalized(); ly = f * -1; lx = cq.Vector(0, 0, 1).cross(ly).normalized(); lz = lx.cross(ly)
        E.comp(webcam(), name, L(pos, lx.toTuple(), lz.toTuple()))
        ball = cq.Vector(*pos) + lz * 27; E.part(cq.Workplane('XY').sphere(7).translate(ball.toTuple()), name + '_ball_joint', 'steel')
        E.part(wire([(cq.Vector(*pos) + lz * 21).toTuple(), ball.toTuple()], 3.2), name + '_stem', 'steel')
        wp = cq.Vector(*wall_pt); n = cq.Vector(*wall_n); mid = cq.Vector(wp.x + n.x * 30, wp.y + n.y * 30, ball.z)
        E.part(wire([ball.toTuple(), mid.toTuple(), (wp.x + n.x * 2, wp.y + n.y * 2, ball.z)], 4.5), name + '_bracket_arm', 'printed')
        E.part(box(40, 4, 40, (0, 0, 0), 4, '|Y'), name + '_wall_plate', 'printed', L((wp.x + n.x * 2, wp.y + n.y * 2, ball.z), (0, 0, 1), (-n.x, -n.y, 0)) * cq.Location((0, 0, 0), (1, 0, 0), 90))
        return cq.Vector(*pos) - ly * 0 + ly * 12 - lz * 12            # USB-C port on the back
    cam1_usb = camera('webcam_overhead', (-200, -150, 540), (0, -80, 60), (-X + pt, -150, 0), (1, 0, 0))
    cam2_usb = camera('webcam_side', (205, -235, 150), (0, -70, 75), (X - pt, -235, 0), (-1, 0, 0))

    # ================= gantry (moves in Y) =================
    bz = P['beamZ']; G = Grp('gantry_Y_axis', None, cq.Location((0, pose['gy'], 0)))
    for sx in (-1, 1):
        cx = sx * 196; cp = box(78, 70, 6, (cx, 0, 47), 4, '|Z')
        wh = [(sx * P['railX'] + a * 21.95, b * 24, 30) for a in (-1, 1) for b in (-1, 1)]
        for p in wh: cp = cp.cut(cyl(2.6, 10, (p[0], p[1], 47)))
        G.part(cp, 'y_carriage_plate', 'steel')
        for p in wh:
            G.comp(vwheel(), 'y_v_wheel', L(p)); G.part(tube(4, 2.6, 8.9, (p[0], p[1], 39.55)), 'wheel_spacer', 'alu'); G.part(shcs(5, 30), 'wheel_bolt', 'steel', L((p[0], p[1], 50)))
        G.part(box(12, 26, 16, (sx * (P['beltX'] + 6.5), 0, 58)).cut(box(2.2, 30, 7, (sx * (P['beltX'] + 6.5), 0, 67))), 'y_belt_clamp', 'printed')
        G.part(extrusion(bz - 20 - 50), 'gantry_upright', 'alu', L((sx * P['railX'], 0, (bz - 20 + 50) / 2)))
        brk(G, (sx * (P['railX'] - 10), 0, 50), (-sx, 0, 0), (0, 0, 1)); brk(G, (sx * (P['railX'] - 10), 0, bz - 20), (-sx, 0, 0), (0, 0, -1))
    G.part(extrusion(2 * P['railX'] + 20, 2), 'x_beam_2040', 'alu', L((0, 0, bz), (0, 1, 0), (1, 0, 0)))
    xm = P['railX'] + 32
    G.comp(nema17(40), 'x_stepper', L((xm, 27, bz), (1, 0, 0), (0, -1, 0))); G.comp(gt2_pulley(), 'x_pulley', L((xm, 16, bz), (1, 0, 0), (0, -1, 0)))
    xp = box(66, 3, 60, (xm - 9, 25.5, bz)).cut(cyl(11.6, 10, (xm, 25.5, bz), 'Y'))
    for a in (-1, 1):
        for b in (-1, 1): xp = xp.cut(cyl(1.7, 10, (xm + a * 15.5, 25.5, bz + b * 15.5), 'Y'))
    G.part(xp, 'x_motor_plate', 'steel'); screws(G, 3, 8, [(xm + a * 15.5, 24, bz + b * 15.5) for a in (-1, 1) for b in (-1, 1)], (0, -1, 0))
    for zz in (bz - 16, bz + 16): G.part(box(20, 14, 8, (P['railX'], 17, zz)), 'x_motor_spacer', 'alu'); G.part(box(20, 14, 8, (-P['railX'], 17, zz)), 'x_idler_spacer', 'alu')
    xi = -(P['railX'] + 8)
    G.comp(idler(), 'x_idler', L((xi, 16, bz), (1, 0, 0), (0, 1, 0))); G.part(cyl(1.5, 18, (xi, 17, bz), 'Y'), 'x_idler_axle', 'steel'); G.part(box(40, 3, 44, (xi + 5, 25.5, bz)), 'x_idler_plate', 'steel')
    for o in (-6.5, 6.5): G.part(box(xm - xi, 6, 1.5, ((xm + xi) / 2, 16, bz + o)), 'x_belt_strand', 'rubber')
    G.comp(limit_switch(), 'limit_switch_x', L((-150, 0, bz + 27), (0, 0, 1), (1, 0, 0)))
    tray = box(340, 16, 2, (10, 36, bz + 36)).union(box(340, 2, 10, (10, 43, bz + 41))).union(box(340, 2, 10, (10, 29, bz + 41)))
    for xx in (-150, 170): tray = tray.union(box(10, 34, 3, (xx, 24, bz + 33.5))).union(box(10, 3, 14, (xx, 8.5, bz + 27)))
    G.part(tray, 'cable_tray', 'printed')

    # ---- X carriage and Z axis (moves in X)
    XC = Grp('x_carriage_Z_axis', G, cq.Location((pose['x'], 0, 0)))
    fp = box(80, 8, 100, (0, -16, bz), 4, '|Y'); rp = box(80, 3, 100, (0, 22, bz), 4, '|Y')
    wz = [(a * 26, 0, bz + b * 31.95) for a in (-1, 1) for b in (-1, 1)]
    for p in wz: fp = fp.cut(cyl(2.6, 20, (p[0], -16, p[2]), 'Y')); rp = rp.cut(cyl(2.6, 20, (p[0], 22, p[2]), 'Y'))
    XC.part(fp, 'x_carriage_front_plate', 'steel'); XC.part(rp, 'x_carriage_rear_plate', 'steel')
    for p in wz:
        XC.comp(vwheel(), 'x_v_wheel', L(p, (1, 0, 0), (0, 1, 0))); XC.part(shcs(5, 43), 'wheel_bolt', 'steel', L((p[0], 23.5, p[2]), (1, 0, 0), (0, 1, 0)))
        XC.part(tube(4, 2.6, 6.9, (p[0], -8.55, p[2]), 'Y'), 'wheel_spacer', 'alu'); XC.part(tube(4, 2.6, 15.4, (p[0], 12.8, p[2]), 'Y'), 'wheel_spacer', 'alu')
    XC.part(box(24, 8, 6, (0, 16.5, bz - 10.6)).union(box(24, 3.4, 8, (0, 18.8, bz - 8))), 'x_belt_clamp', 'printed')
    XC.part(extrusion(240), 'z_rail_2020', 'alu', L((0, -30, 410)))
    lr = box(12, 8, 240, (0, -44, 410))
    for i in range(10): lr = lr.cut(cyl(1.75, 12, (0, -44, 297.5 + i * 25), 'Y')).cut(cyl(3, 4.5, (0, -46.2, 297.5 + i * 25), 'Y'))
    XC.part(lr, 'z_linear_rail_MGN12', 'steel')                      # 12 x 8 mm rail on the front face of the Z extrusion (pub)
    zx, zy = 24, -43                                                # lead screw position, kept clear of the rail corner and of the raised probe
    XC.part(cyl(4, 205, (zx, zy, 402.5)), 'z_lead_screw_T8', 'steel'); XC.part(tube(9.5, 4, 25, (zx, zy, 517.5)), 'z_coupler', 'alu')
    zp = box(72, 60, 4, (11, -42, 532)).cut(cyl(11.6, 10, (zx, zy, 532)))
    for a in (-1, 1):
        for b in (-1, 1): zp = zp.cut(cyl(1.7, 10, (zx + a * 15.5, zy + b * 15.5, 532)))
    XC.part(zp, 'z_motor_plate', 'steel'); XC.comp(nema17(34), 'z_stepper', L((zx, zy, 534), (1, 0, 0), (0, 0, -1)))
    screws(XC, 3, 8, [(zx + a * 15.5, zy + b * 15.5, 530) for a in (-1, 1) for b in (-1, 1)], (0, 0, -1))

    # ---- Z slide: a plate on two linear rail carriages, then a head that floats on two guide rods
    zsZ = P['face_z_raised'] + Lp + 152; ZS = Grp('z_slide', XC, cq.Location((0, 0, zsZ - pose['zdown']))); pd = P['probe_dy']
    XC.comp(limit_switch(), 'limit_switch_z', L((-36, -56, zsZ + 33), (0, 1, 0), (0, 0, -1)))
    XC.part(box(26, 10, 14, (-23, -33, zsZ + 45)).union(box(8, 26, 6, (-36, -49, zsZ + 41))), 'printed_z_switch_bracket', 'printed')
    sp = box(62, 6, 120, (0, -56, 0), 3, '|Y').union(box(10, 6, 6, (-35, -56, 20))).union(box(52, 83, 6, (0, -100.5, -20))).union(box(22, 20, 12, (25, -43, 0)))
    for sx in (-1, 1): sp = sp.union(cq.Workplane('YZ').polyline([(-59, -17), (-59, 24), (-138, -17)]).close().extrude(3).translate((sx * 21 - 1.5, 0, 0)))
    rods_y = (pd - 16, pd + 16)
    sp = sp.cut(cyl(5.2, 30, (zx, zy, 0))).cut(cyl(11.3, 4, (zx, zy, 7.9)))
    for ry in rods_y: sp = sp.cut(cyl(6.05, 20, (0, ry, -20)))
    for zz in (-38, 38):
        for a in (-1, 1):
            for b in (-1, 1): sp = sp.cut(cyl(1.7, 10, (a * 10, -56, zz + b * 10), 'Y'))
    ZS.part(sp, 'z_slide_plate_and_bracket', 'steel')
    for zz in (-38, 38):
        ZS.comp(mgn12h(), 'z_carriage_MGN12H', L((0, -48, zz))); screws(ZS, 3, 8, [(a * 10, -59, zz + b * 10) for a in (-1, 1) for b in (-1, 1)], (0, -1, 0))
    ZS.part(tube(11, 4, 3.5, (zx, zy, 7.75)).union(tube(5.1, 4, 14, (zx, zy, -1))), 'z_lead_nut', 'brass')
    for ry in rods_y: ZS.part(tube(6, 3.1, 14, (0, ry, -20)).union(tube(8, 3.1, 2, (0, ry, -16))), 'float_bushing', 'brass')
    ZS.comp(limit_switch(), 'limit_switch_overtravel', L((22, pd, -28), (1, 0, 0), (0, 0, -1)))
    ZS.comp(hx711(), 'load_cell_amp_HX711', L((0, -63.5, 30), (1, 0, 0), (0, -1, 0)))  # beside the load cell, so only a digital signal travels down the moving harness
    for a in (-1, 1):
        for b in (-1, 1): ZS.part(tube(2.2, 1.1, 4.5, (a * 9.8, -61.25, 30 + b * 13.3), 'Y'), 'load_cell_amp_standoff', 'brass')
    # the floating head: it hangs on its collars, and lifts freely by float_travel if the probe is pushed up, so contact force cannot exceed its own weight
    FL = Grp('floating_head', ZS, cq.Location((0, 0, pose['float'])))
    car = box(88, 50, 5, (0, pd, -44.5), 4, '|Z')
    for xx in (-35, -20): car = car.cut(cyl(2.1, 20, (xx, pd, -44.5)))
    FL.part(car, 'float_carrier_plate', 'steel')
    for ry in rods_y: FL.part(cyl(3, 42, (0, ry, -26)), 'float_guide_rod', 'steel'); FL.part(tube(6.5, 3, 6, (0, ry, -10)), 'float_stop_collar', 'steel')
    FL.comp(load_cell(), 'load_cell_TAL220B', L((0, pd, -53.4))); screws(FL, 4, 16, [(-35, pd, -42), (-20, pd, -42)])
    sm = box(66, 31, 2.7, (10, pd, -61.1)).union(box(47.5, 31, 14, (7.25, pd, -69.5)).cut(box(45.6, 25.1, 20, (12.1, pd, -70))))   # cradle that grips the yaw servo body, leaving its socket end free
    for xx in (20, 35): sm = sm.cut(cyl(2.1, 20, (xx, pd, -61)))
    for xx in (-4, 18): sm = sm.cut(cyl(1.6, 40, (xx, pd, -72), 'Y'))
    FL.part(sm, 'printed_yaw_servo_mount', 'printed'); screws(FL, 3, 8, [(xx, pd - 15.5, -72) for xx in (-4, 18)], (0, -1, 0)); screws(FL, 3, 8, [(xx, pd + 15.5, -72) for xx in (-4, 18)], (0, 1, 0))
    yawz = -107
    FL.comp(st3215(), 'servo_yaw', L((0, pd, yawz), (1, 0, 0), (0, 0, -1))); FL.comp(st3215_horn(), 'servo_yaw_horn', L((0, pd, yawz), (1, 0, 0), (0, 0, -1)))

    hw, ht = w + 12, t + 12; rx, rz = hw / 2 + 16.5, ht / 2 + 5.5; armX = rx + 13.5; up = Lp - 10
    rot = lambda ax, deg: cq.Location((0, 0, 0), ax, deg)
    YAW = Grp('gimbal_yaw', FL, cq.Location((0, pd, yawz)) * rot((0, 0, 1), pose['yaw'])); PIT = Grp('gimbal_pitch', YAW, cq.Location((0, 0, -up)) * rot((1, 0, 0), pose['pitch'])); ROL = Grp('gimbal_roll', PIT, rot((0, 1, 0), pose['roll']))
    yoke = box(2 * armX + 8, 28, 6, (0, 0, up - 8.2), 2, '|Z')
    for sx in (-1, 1): yoke = yoke.union(box(6, 28, up - 5.2 + 16, (sx * armX, 0, (up - 5.2 - 16) / 2))).union(cyl(8, 7, (sx * armX, 0, 0), 'X'))
    yoke = yoke.union(box(16, 30.7, 41.5, (armX + 11, 0, 7.25)))                 # cradle for the pitch servo body
    yoke = yoke.cut(cyl(2.1, 2 * armX + 20, (0, 0, 0), 'X')).cut(cyl(9.8, 20, (armX, 0, 0), 'X')).cut(box(40, 25.1, 45.6, (armX + 23.4, 0, 12.1))).cut(cyl(1.6, 20, (0, 0, up - 8.2)))
    for a in range(0, 360, 60): yoke = yoke.cut(cyl(1.1, 20, (8 * math.cos(math.radians(a)), 8 * math.sin(math.radians(a)), up - 8.2)))
    for zz in (30, 70, 110): yoke = yoke.cut(box(20, 6, 3, (armX, 14, zz)))                                    # cable tie slots down the servo-side arm
    YAW.part(yoke.translate((0, 0, -up)), 'printed_yoke', 'printed')
    YAW.comp(st3215(), 'servo_pitch', L((armX - 0.6, 0, -up), (0, 0, 1), (-1, 0, 0))); YAW.comp(st3215_horn(), 'servo_pitch_horn', L((armX - 0.6, 0, -up), (0, 0, 1), (-1, 0, 0)))
    screws(YAW, 3, 8, [(armX + 11, 15.35, zz - up) for zz in (-4, 18)], (0, 1, 0)); screws(YAW, 3, 8, [(armX + 11, -15.35, zz - up) for zz in (-4, 18)], (0, -1, 0))
    YAW.part(cyl(2, armX - rx + 6, (-(rx + armX) / 2, 0, -up), 'X'), 'pitch_pin', 'steel')
    ring = box(2 * rx + 5, 2 * rz + 5, 18, (0, 0, 0), 3, '|Z').cut(box(2 * rx - 5, 2 * rz - 5, 30, (0, 0, 0)))
    ring = ring.union(box(41.5, 16, 30.7, (-7.25, rz + 10.5, 0)))                # cradle for the roll servo body
    ring = ring.cut(cyl(2.1, 2 * rx + 20, (0, 0, 0), 'X')).cut(cyl(2.1, 2 * rz + 20, (0, 0, 0), 'Y')).cut(cyl(9.8, 12, (0, rz, 0), 'Y')).cut(box(45.6, 40, 25.1, (-12.1, rz + 24.1, 0)))
    PIT.part(ring, 'printed_pitch_ring', 'printed')
    PIT.comp(st3215(), 'servo_roll', L((0, rz + 0.4, 0), (-1, 0, 0), (0, -1, 0))); PIT.comp(st3215_horn(), 'servo_roll_horn', L((0, rz + 0.4, 0), (-1, 0, 0), (0, -1, 0)))
    screws(PIT, 3, 8, [(xx, rz + 10.5, 15.35) for xx in (4, -18)], (0, 0, 1)); screws(PIT, 3, 8, [(xx, rz + 10.5, -15.35) for xx in (4, -18)], (0, 0, -1))
    PIT.part(cyl(2, rz - ht / 2 + 6, (0, -(rz + ht / 2) / 2, 0), 'Y'), 'roll_pin', 'steel')
    zc = ht / 2 + P['stamp_gap']
    sleeve = box(hw, ht, 60, (0, 0, 0), 2.5, '|Z').cut(box(w + 2, t + 2, 70, (0, 0, 0)))
    for zz in (-14, 14): sleeve = sleeve.union(box(7, 5, 12, (hw / 2 + 3.5, 3.4, zz))).union(box(7, 5, 12, (hw / 2 + 3.5, -3.4, zz))).cut(cyl(1.7, 20, (hw / 2 + 4, 0, zz), 'Y'))
    sleeve = sleeve.cut(box(16, 1.8, 64, (hw / 2 + 2, 0, 0))).cut(cyl(2.1, ht + 20, (0, 0, 0), 'Y'))
    sleeve = sleeve.union(box(14, zc - 8 - ht / 2 + 1, 8, (0, -(ht / 2 + (zc - 8 - ht / 2) / 2), -21)))                       # arm out to the pen guide
    sleeve = sleeve.union(box(16, 16, 30, (0, -zc, -12), 2, '|Z')).union(box(14, 22, 3, (14.5, -zc, -2))).cut(cyl(3.9, 60, (0, -zc, -12)))   # pen guide and the shelf for its lift servo
    tof_xy = [(hw / 2 + 5, 12), (-(hw / 2 + 5), 0), (-22, ht / 2 + 5), (-22, -(ht / 2 + 5))]                                    # four distance sensors looking down around the probe
    for qx, qy in tof_xy: sleeve = sleeve.union(box(8 if abs(qx) > hw / 2 else 12, 12, 2.5, (qx - (1.5 if qx > hw / 2 else -1.5 if qx < -hw / 2 else 0), qy, -27.5)))   # low on the holder, so they clear the tilt ring at full roll
    ROL.part(sleeve, 'printed_probe_holder', 'printed'); screws(ROL, 3, 12, [(hw / 2 + 4, 6, zz) for zz in (-14, 14)], (0, 1, 0), 'clamp_screw')
    ROL.comp(micro_servo(), 'marker_lift_servo', L((14.5, -zc, 16)))
    ROL.part(cyl(3.5, 62, (0, -zc, -10)), 'marker_pen', 'white'); ROL.part(tube(5.5, 3.6, 5, (0, -zc, 19)).union(box(3, 9, 3, (0, -zc - 9.6, 19))), 'marker_pen_collar', 'printed')
    for qx, qy in tof_xy: ROL.comp(tof_sensor(), 'distance_sensor', L((qx, qy + (2.6 if qy > 20 else -2.6 if qy < -20 else 0), -28.75)))
    ROL.part(box(18, 1.2, 18, (-22.5, -(ht / 2 + 0.6), 12)), 'head_tracking_marker', 'white'); ROL.part(box(12, 0.4, 12, (-22.5, -(ht / 2 + 1.4), 12)), 'head_tracking_marker_print', 'black')
    ROL.part(cq.Workplane('XY').circle(3.2).workplane(offset=-6).circle(2).loft().translate((0, -zc, -41)), 'marker_felt_tip', 'red')
    ROL.comp(bno085(), 'tilt_sensor_BNO085', L((-hw / 2, 0, 14), (0, 1, 0), (-1, 0, 0)))
    ROL.comp(probe_butterfly(Lp, w, t) if isB else probe_vscan(Lp, w, t), 'probe_' + variant, L((0, 0, -P['pivot_up'])))
    # one spring per tilt joint keeps its gears pressed to one side, which takes out the free play (drawn at the neutral pose, left out of the clash check)
    def spring(g, a, b, name): g.asm.add(wire([a, b], 1.6), name=uniq(name), color=cq.Color(*COL['steel']))
    spring(FL, (-28, pd - 16, -66), (-22, pd + 13, yawz - 5.5), 'preload_spring_yaw')
    spring(YAW, (-armX + 3.5, 11, -up + 34), (-(rx + 2.5), 11, -up + 9.5), 'preload_spring_pitch')
    spring(PIT, (-(rx - 2.5), 14, -9.5), (-(hw / 2 + 0.5), 14, -24), 'preload_spring_roll')
    ZS.comp(head_board(), 'head_sensor_board', L((0, -63.5, -4), (1, 0, 0), (0, -1, 0))); ZS.part(box(12, 4.5, 12, (0, -61.25, -4)), 'head_sensor_board_spacer', 'printed')

    # ================= power and control hardware, outside the back wall =================
    K = Grp('electronics_bay'); o = back
    out = lambda x, z: L((x, o + 6, z), (1, 0, 0), (0, 1, 0)); outv = lambda x, z: L((x, o + 6, z), (0, 0, 1), (0, 1, 0))
    K.comp(psu(), 'psu_24V_350W', L((-140, o, 345)))
    K.comp(fuse_block(), 'fuse_block', L((-225, o, 258), (1, 0, 0), (0, 1, 0)))
    K.comp(buck_small(), 'converter_12V_D36V50F12', out(-180, 258)); standoffs(K, -180, 258, 25.4, 25.4, 2.2, o, 6, 'converter_12V')
    K.comp(buck_large(), 'converter_12V_servo_D24V150F12', out(-135, 258)); standoffs(K, -135, 258, 43.2, 31.8, 3, o, 6, 'converter_12V_servo')
    K.comp(relay(), 'motion_power_relay', out(-90, 200))       # the stop button opens this relay's coil, and the relay carries the motor current
    K.comp(buck_small(), 'converter_5V_D36V50F5', out(-90, 258)); standoffs(K, -90, 258, 25.4, 25.4, 2.2, o, 6, 'converter_5V')
    K.comp(usb_hub(), 'usb_hub_powered', L((-12, o, 322), (0, 0, -1), (0, 1, 0)))
    K.comp(teensy40(), 'teensy_4_0', outv(-225, 200)); K.part(box(22, 3.4, 40, (-225, o + 1.7, 200)), 'teensy_carrier', 'printed')
    K.comp(bus_adapter(), 'servo_bus_adapter', out(-180, 200)); standoffs(K, -180, 200, 42, 33, 2.5, o, 6, 'servo_bus_adapter')
    K.comp(mains_inlet(), 'mains_inlet_C14', L((-232, o + 30, 50), (-1, 0, 0), (0, 1, 0)))
    shelf = box(150, 96, 5, (-140, o + 48, 87.5), 3, '|Z')
    for sx in (-1, 1): shelf = shelf.union(cq.Workplane('YZ').polyline([(o, 85), (o + 80, 85), (o, 25)]).close().extrude(4).translate((-140 + sx * 66 - 2, 0, 0)))
    K.part(shelf, 'electronics_shelf', 'plate'); K.comp(controller_box(), 'motion_controller', L((-140, o + 48, 90)))
    K.comp(jetson(), 'jetson_orin_nano_devkit', L((-140, o + 48, 132)))
    for a in (-1, 1):
        for b in (-1, 1): K.part(tube(3, 1.4, 6, (-140 + a * 46, o + 48 + b * 35.5, 129)), 'jetson_standoff', 'brass')
    if not isB:
        x0, x1, z0, z1, d = 30, 215, 70, 263, 100; cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
        shell = box(x1 - x0, d, z1 - z0, (cx, o + d / 2, cz)).cut(box(x1 - x0 - 6, d - 3, z1 - z0, (cx, o + d / 2 - 1.5, cz + 3))).cut(cyl(8, 20, (46, o, 100), 'Y'))
        K.part(shell, 'light_box_shell', 'dark'); K.part(box(x1 - x0 + 4, d + 2, 3, (cx, o + d / 2 + 1, z1 + 1.5)).union(box(x1 - x0 - 7, d - 4, 3, (cx, o + d / 2 - 1.5, z1 - 1.5))), 'light_box_lid', 'dark')
        K.part(box(22, 76, 168, (x0 + 22, o + d / 2, z0 + 8 + 84), 6, '|X'), 'vscan_display_unit', 'white'); K.part(box(0.6, 64, 110, (x0 + 33.3, o + d / 2, z0 + 108)), 'vscan_display_screen', 'glass')
        K.part(box(34, 84, 10, (x0 + 22, o + d / 2, z0 + 8)).cut(box(22.6, 76.6, 8, (x0 + 22, o + d / 2, z0 + 10))), 'printed_display_cradle', 'printed')
        K.part(box(1.6, 24, 25, (x1 - 10, o + d / 2, z0 + 108)), 'camera_IMX219_board', 'pcb'); K.part(cyl(4, 6, (x1 - 16, o + d / 2, z0 + 108), 'X').union(box(5, 9, 9, (x1 - 13.4, o + d / 2, z0 + 108))), 'camera_IMX219_lens', 'black')
        K.comp(grommet(), 'probe_cable_grommet', L((46, back - pt / 2, 100), (1, 0, 0), (0, 1, 0)))

    # ================= wiring =================
    Wg = Grp('wiring'); nw = [0]
    def run(kind, name, pts):
        Wg.asm.add(wire(pts, WR[kind]), name=uniq('wire_' + name), color=cq.Color(*COL['w_' + kind])); nw[0] += 1
    if wiring:
        lay = [0]
        def OUT(kind, name, a, b, via=()):                      # a wire that stays outside the back wall, in its own depth layer
            y = o + 26 + 2.5 * (lay[0] % 12); lay[0] += 1
            run(kind, name, [a, (a[0], y, a[2])] + [(v[0], y, v[1]) for v in via] + [(b[0], y, b[2]), b])
        slot = [0]
        def THRU(kind, name, a, via_out, inside):               # outside terminal -> pass-through -> inside way-points
            k = slot[0]; slot[0] += 1; ox, oz = ((k % 6) - 2.5) * 4.2, ((k // 6) - 2.5) * 4.2; y = o + 26 + 2.5 * (lay[0] % 12); lay[0] += 1
            g = (px0 + ox, pz0 + oz)
            run(kind, name, [a, (a[0], y, a[2])] + [(v[0], y, v[1]) for v in via_out] + [(g[0], y, g[1]), (g[0], o + 8, g[1]), (g[0], back - pt - 8, g[1])] + [tuple(p) for p in inside(g, k)])
        t_psu_ac, t_psu_dc = (-236, o + 22, 385), (-236, o + 22, 315)
        OUT('mains', 'inlet_to_psu', (-232, o + 34, 76), t_psu_ac, [(-252, 100), (-252, 385)])
        OUT('v24', 'psu_to_fuse_block', t_psu_dc, (-225, o + 18, 276))
        OUT('v24', 'fuse_to_12V_converter', (-222, o + 18, 240), (-185, o + 9, 266), [(-200, 232), (-200, 274)])
        OUT('v24', 'fuse_to_5V_converter', (-228, o + 18, 240), (-95, o + 9, 266), [(-208, 228), (-108, 228), (-108, 278)])
        OUT('v12', '12V_to_jetson', (-175, o + 9, 250), (-98, o + 82, 139), [(-162, 236), (-62, 236), (-62, 150)])
        OUT('v12', 'servo_converter_to_bus_adapter', (-120, o + 14, 252), (-166, o + 12, 191), [(-112, 240), (-156, 240)])
        OUT('usb', 'hub_to_servo_bus_adapter', (-2, o + 12, 270), (-196, o + 9, 200), [(12, 270), (12, 160), (-206, 160)])
        OUT('v5', '5V_to_usb_hub', (-85, o + 9, 250), (-12, o + 12, 374), [(-70, 244), (-30, 244), (-30, 384)])
        OUT('usb', 'jetson_to_usb_hub', (-176, o + 82, 142), (-2, o + 12, 283), [(-176, 178), (10, 178)])
        OUT('usb', 'hub_to_teensy', (-2, o + 12, 296), (-225, o + 8, 182), [(14, 296), (14, 172), (-225, 172)])
        OUT('usb', 'hub_to_motion_controller', (-2, o + 12, 309), (-85, o + 90, 108), [(18, 309), (18, 112)])
        if not isB: OUT('usb', 'jetson_to_light_box_camera', (-123, o + 82, 139), (222, o + 50, 178), [(-123, 60), (222, 60)])

        ZI = lambda k: back - pt - 6 - 2.4 * (k % 5)             # depth layer for a wire running on the inside of the back wall
        def to_top(g, k, zrun):                                 # up the back wall, across to the left wall, forward along the left top rail
            xl = -X + pt + 5 + 2.4 * (k % 5)
            return [(g[0], ZI(k), g[1]), (g[0], ZI(k), zrun), (xl, ZI(k), zrun), (xl, fyB - 30, zrun)]
        def hood_pts(k, s_dev, x_dev, y_dev=pt + 4):            # along the left top rail to the panel, down its left rail, across to a device
            xl = -X + pt + 5 + 2.4 * (k % 5); zr = top - 34 - 2.6 * k; xh = -fx + 14 + 2.4 * (k % 5)
            return [(xl, P['hood_top_y'] + 40, zr), H.W(xh, pt + 24, hl - 24), H.W(xh, pt + 24, s_dev), H.W(x_dev, pt + 24, s_dev), H.W(x_dev, y_dev, s_dev)]
        def base_run(g, k, x_end, zl):                          # down the back wall, along its foot, forward along the base
            return [(g[0], ZI(k), g[1]), (g[0], ZI(k), zl), (x_end, ZI(k), zl)]
        # power and data to the front panel
        est = lambda dx: (lambda g, k: to_top(g, k, top - 34 - 2.6 * k) + hood_pts(k, esz + dx, esx, pt + 44))
        THRU('v24', 'fuse_to_estop', (-225, o + 18, 236), [(-212, 226), (-40, 226)], est(-8))
        THRU('v24', 'estop_to_relay_coil', (-84, o + 22, 206), [(-70, 206), (-70, 284), (-34, 284)], est(8))
        OUT('v24', 'fuse_to_relay_contact', (-219, o + 18, 240), (-96, o + 22, 196), [(-214, 222), (-100, 222)])
        OUT('v24', 'relay_to_motion_bus', (-90, o + 22, 194), (-133, o + 14, 268), [(-76, 190), (-76, 288), (-133, 288)])
        OUT('v24', 'estop_bus_to_servo_converter', (-135, o + 14, 270), (-150, o + 14, 264), [(-143, 276)])
        OUT('v24', 'estop_bus_to_motion_controller', (-131, o + 14, 268), (-190, o + 60, 104), [(-66, 280), (-66, 120), (-205, 120)])
        THRU('usb', 'hub_to_webcam_overhead', (-2, o + 12, 335), [(22, 335), (22, 250)], lambda g, k: to_top(g, k, top - 34 - 2.6 * k) + [(-X + pt + 5 + 2.4 * (k % 5), -150, top - 34 - 2.6 * k), (-X + pt + 14, -150, 566), cam1_usb.toTuple()])
        THRU('usb', 'hub_to_webcam_side', (-2, o + 12, 348), [(24, 348), (24, 254)], lambda g, k: [(g[0], ZI(k), g[1]), (g[0], ZI(k), 70), (231, ZI(k), 70), (231, 226, 70), (250, 226, 70), (250, -235, 70), (250, -235, 140), cam2_usb.toTuple()])
        def led(g, k):
            return [(g[0], ZI(k), g[1]), (g[0], ZI(k), top - 30), (g[0], fyB + 2, top - 26)]
        THRU('v12', '12V_to_led_strips', (-182, o + 9, 248), [(-166, 222), (-50, 222)], led)
        run('v12', 'led_jumper_back_to_left', [(-fx + 16, fyB, top - 26), (-fx + 4, fyB - 4, top - 27), (-fx, fyB - 16, top - 26)])
        run('v12', 'led_jumper_back_to_right', [(fx - 16, fyB, top - 26), (fx - 4, fyB - 4, top - 27), (fx, fyB - 16, top - 26)])
        run('v12', 'led_jumper_left_to_front', [(-fx, P['hood_top_y'] + 32, top - 26), H.W(-fx + 20, pt + 28, hl - 30), H.W(-fx + 20, pt + 28, 30), H.W(-fx + 30, pt + 25, 12)])
        # along the base: Y steppers, Y limit switch, pressure pads
        THRU('step', 'controller_to_y_stepper_left', (-150, o + 90, 104), [(-150, 60), (-30, 60)], lambda g, k: base_run(g, k, -P['beltX'], 16) + [(-P['beltX'], 247, 20)])
        THRU('step', 'controller_to_y_stepper_right', (-140, o + 90, 104), [(-140, 56), (-26, 56)], lambda g, k: base_run(g, k, P['beltX'], 19) + [(P['beltX'], 247, 22)])
        THRU('sig', 'controller_to_limit_switch_y', (-126, o + 90, 104), [(-126, 52), (-22, 52)], lambda g, k: base_run(g, k, -P['railX'] - 16, 22) + [(-P['railX'] - 16, 200, 22), (-P['railX'] - 7, 196, 46)])
        for i, (px_, y) in enumerate(pad_xy):
            sx = 1 if px_ > 0 else -1; xr = sx * (82 + 1.8 * i)
            THRU('sig', f'teensy_to_pressure_pad_{i + 1}', (-229, o + 8, 190 + 3 * i), [(-244 + 1.5 * i, 150 + 2 * i), (-60 + 3 * i, 150 + 2 * i)],
                 lambda g, k, y=y, xr=xr, i=i, sx=sx: base_run(g, k, xr, 14 + 0) + [(xr, 66, 14), (xr, -244 + 2 * i, 14), (sx * 52, -244 + 2 * i, 14), (sx * 52, -244 + 2 * i, 31.5), (sx * 52, y, 31.5), (sx * 41, y, 23.4)])
        # the moving harness: back wall -> gantry cable tray -> X carriage -> Z slide -> gimbal
        hn = [0]
        def harness(kind, name, a, via_out, tail, upto):
            j = hn[0]; hn[0] += 1; dy, dz = (j % 4) * 3.0 - 4.5, (j // 4) * 3.0
            def inside(g, k):
                p = [(g[0], ZI(k), g[1]), (g[0], ZI(k), 300 + dz * 2), (150 + dy, ZI(k), 300 + dz * 2)]
                a0 = (150 + dy, ZI(k), 300 + dz * 2); b0 = G.W(150 + dy, 36 + dy * 0.8, bz + 40 + dz)
                p += [((a0[0] + b0[0]) / 2, (a0[1] + b0[1]) / 2, min(a0[2], b0[2]) - 40 + dz), b0]                      # slack loop that lets the gantry travel
                if upto == 'gantry': return p + [G.W(*q) for q in tail]
                p += [G.W(-110 + dy, 36 + dy * 0.8, bz + 40 + dz), G.W(-60 + dy, 30, bz + 80 + dz), XC.W(-20 + dy, 26, bz + 58 + dz), XC.W(-20 + dy, -24, bz + 58 + dz)]   # arch that lets the carriage travel
                if upto == 'xc': return p + [XC.W(*q) for q in tail]
                p += [XC.W(-44 + dy * 0.5, -30 + dz, 470), ZS.W(-40 + dy * 0.5, -66 + dz, 40), ZS.W(-34 + dy * 0.5, -66, -8)]
                if upto == 'zs': return p + [ZS.W(*q) for q in tail]
                p += [ZS.W(-34 + dy * 0.5, pd - 30, -30), FL.W(-30 + dy * 0.5, pd - 30, -66), YAW.W(armX - 6 + dz * 0.6, -18 - dy * 0.6, -14), YAW.W(armX + 0.5, -17 - dy * 0.6, -30), YAW.W(armX + 0.5, -17 - dy * 0.6, -up + 46)]
                return p + [(PIT if upto == 'pit' else ROL if upto == 'rol' else YAW).W(*q) for q in tail]
            THRU(kind, name, a, via_out, inside)
        ct = lambda i: (-170 + 8 * i, o + 90, 104)
        harness('step', 'controller_to_x_stepper', ct(0), [(-170, 64), (-34, 64)], [(xm - 30, 50, bz + 40), (xm, 62, bz + 30), (xm, 62, bz + 23)], 'gantry')
        harness('sig', 'controller_to_limit_switch_x', ct(6), [(-122, 48), (-18, 48)], [(-150, 36, bz + 40), (-158, 0, bz + 40), (-157, 0, bz + 27)], 'gantry')
        harness('step', 'controller_to_z_stepper', ct(1), [(-162, 68), (-38, 68)], [(-34, -30, 560), (-10, -66, 574), (24, -66, 569)], 'xc')
        harness('sig', 'controller_to_limit_switch_z', ct(7), [(-114, 44), (-14, 44)], [(-44, -40, zsZ + 50), (-40, -56, zsZ + 44), (-36, -56, zsZ + 40)], 'xc')
        harness('sig', 'teensy_to_head_board_serial', (-217, o + 8, 206), [(-204, 166), (-60, 166)], [(-20, -67, -2), (-9, -67, -2)], 'zs')
        harness('v5', '5V_to_head_board', (-92, o + 9, 248), [(-80, 222), (-44, 222)], [(-22, -67, -8), (-9, -67, -8)], 'zs')
        run('sig', 'head_board_to_load_cell_amp', [ZS.W(4, -66, 6), ZS.W(6, -69, 12), ZS.W(4, -66, 17)])
        run('sig', 'load_cell_to_amp', [FL.W(-40, pd, -53.4), FL.W(-50, pd, -53.4), ZS.W(-50, pd + 20, -30), ZS.W(-36, -68, -4), ZS.W(-18, -67, 42), ZS.W(-6, -67, 42)])
        harness('sig', 'teensy_to_overtravel_switch', (-233, o + 8, 196), [(-250, 136), (-32, 136)], [(-34, pd + 10, -30), (14, pd + 8, -34), (22, pd, -36)], 'zs')
        harness('bus', 'servo_bus_adapter_to_yaw_servo', (-178, o + 10, 211), [(-204, 244), (-58, 244)], [(-48, pd - 20, -40), (-48, pd - 20, -80), (30, pd - 22, -85), (37, pd - 5, -85)], 'zs')
        run('bus', 'servo_bus_yaw_to_pitch', [FL.W(37, pd + 5, -85), FL.W(50, pd + 8, -85), YAW.W(armX + 6, -24, -8), YAW.W(armX + 24, -20, -30), YAW.W(armX + 24, -16, -up + 52), YAW.W(armX + 21.4, -5, -up + 37.5)])
        run('bus', 'servo_bus_pitch_to_roll', [YAW.W(armX + 21.4, 5, -up + 37.5), YAW.W(armX + 21.4, 20, -up + 46), YAW.W(armX - 8, 30, -up + 42), PIT.W(10, rz + 46, 22), PIT.W(-46, rz + 40, 12), PIT.W(-37.5, rz + 22.4, 5)])
        gim = lambda dy: [ZS.W(9, -67, -6), ZS.W(-34, -67, -14), ZS.W(-34 + dy, pd - 30, -30), FL.W(-30 + dy, pd - 30, -66), YAW.W(armX - 6, -18 - dy, -14), YAW.W(armX + 0.5, -17 - dy, -30), YAW.W(armX + 0.5, -17 - dy, -up + 46)]   # head board down through the gimbal
        run('sig', 'head_board_to_tilt_sensor', gim(0) + [ROL.W(armX - 12, -(rz + 10), 34), ROL.W(-(hw / 2 + 12), -(ht / 2 + 6), 32), ROL.W(-(hw / 2 + 5), -9.5, 16), ROL.W(-(hw / 2 + 3.1), -9.5, 14)])
        run('sig', 'tilt_sensor_to_distance_sensors', [ROL.W(-(hw / 2 + 3.1), -6, 8), ROL.W(-(hw / 2 + 7), -4, -10), ROL.W(-(hw / 2 + 5), 0, -26.5)])
        run('sig', 'distance_sensor_chain_back', [ROL.W(-(hw / 2 + 5), 0, -26.5), ROL.W(-(hw / 2 + 7), ht / 2 + 7, -26.5), ROL.W(-22, ht / 2 + 5, -26.5), ROL.W(hw / 2 + 7, ht / 2 + 7, -26.5), ROL.W(hw / 2 + 5, 12, -26.5)])
        run('sig', 'distance_sensor_chain_front', [ROL.W(-(hw / 2 + 5), 0, -26.5), ROL.W(-(hw / 2 + 7), -(ht / 2 + 7), -26.5), ROL.W(-22, -(ht / 2 + 5), -26.5)])
        run('v5', 'head_board_to_marker_servo', gim(3) + [ROL.W(armX - 16, -(rz + 12), 40), ROL.W(26, -zc + 4, 36), ROL.W(21, -zc, 27)])
        # probe cable
        if isB:
            g1, g2 = H.W(phx, pt + 30, phz), H.W(phx, -10, phz)
            run('probe', 'probe_cable_to_ipad', [ROL.W(0, 0, -P['pivot_up'] + Lp + 18), ROL.W(0, -30, -P['pivot_up'] + Lp + 26), ROL.W(30, -70, 60), (90, -150, 250), g1, g2, H.W(phx - 6, -16, phz), H.W(ipx + 97.7 + 9, -5.55, ips), H.W(ipx + 97.7 + 1, -5.55, ips)])
        else:
            run('probe', 'probe_cable_to_display', [ROL.W(0, t / 2 + 18, -P['pivot_up'] + Lp - 34), ROL.W(0, t / 2 + 50, -P['pivot_up'] + Lp - 34), (30, 120, 200), (46, 200, 110), (46, back - 12, 100), (46, o + 14, 100), (52, o + 40, 90), (52, o + 50, 84)])
    for g in reversed(groups): (g.parent.asm if g.parent else root).add(g.asm)          # children are attached before their parents, so nothing is copied empty
    info = dict(pivot=ROL.W(0, 0, 0), probe_face_z=ROL.W(0, 0, -P['pivot_up'])[2], wires=nw[0], solids=len(flat), stamp_offset=zc,
                groups=dict(G=G, XC=XC, ZS=ZS, FL=FL, YAW=YAW, PIT=PIT, ROL=ROL), geo=dict(zsZ=zsZ, pd=pd, up=up, yawz=yawz))
    return root, flat, dict(yoke=yoke, pitch_ring=ring, probe_holder=sleeve, yaw_servo_mount=sm, cable_tray=tray, ipad_slot=ipad_slot), info


if __name__ == '__main__':
    import time
    for v in (sys.argv[1:] or ['butterfly', 'vscan']):
        t0 = time.time(); A, flat, printed, info = build(v)
        A.export(f'out2/UltraVena_rig_{v}_detailed.step'); A.export(f'out2/{v}.glb', tolerance=0.15, angularTolerance=0.3)
        for n, part in printed.items(): cq.exporters.export(part, f'out2/{v}_{n}.stl', tolerance=0.05)
        print(v, {k: info[k] for k in ('pivot', 'probe_face_z', 'wires', 'solids', 'stamp_offset')}, 'seconds', round(time.time() - t0))
