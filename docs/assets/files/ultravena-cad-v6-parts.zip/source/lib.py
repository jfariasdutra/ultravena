"""Component library for the UltraVena rig model. Every function returns a list of (solid, name, colour) in the component's own frame.
Sizes marked (pub) are published figures, (est) are estimates to replace with supplier STEP models or measurements."""
import math, functools
import cadquery as cq

COL = dict(alu=(0.78, 0.8, 0.82), dark=(0.13, 0.14, 0.16), plate=(0.17, 0.2, 0.22), motor=(0.09, 0.09, 0.1), steel=(0.62, 0.65, 0.68), printed=(0.2, 0.77, 0.67),
           servo=(0.12, 0.12, 0.13), pad=(0.23, 0.27, 0.3), pcb=(0.07, 0.38, 0.22), pcb_blue=(0.1, 0.2, 0.55), pcb_red=(0.6, 0.1, 0.1), pcb_black=(0.06, 0.06, 0.07),
           probe=(0.1, 0.14, 0.24), white=(0.92, 0.93, 0.91), glass=(0.04, 0.08, 0.11), red=(0.88, 0.15, 0.17), yellow=(0.95, 0.76, 0.1), gold=(0.79, 0.63, 0.24),
           copper=(0.72, 0.45, 0.2), brass=(0.8, 0.68, 0.3), led=(1, 0.97, 0.85), black=(0.04, 0.04, 0.05), panel=(0.55, 0.62, 0.68, 0.25), rubber=(0.03, 0.03, 0.03), lens=(0.3, 0.33, 0.37),
           w_mains=(0.6, 0.42, 0.23), w_v24=(0.9, 0.22, 0.23), w_v12=(0.96, 0.77, 0.19), w_v6=(1, 0.55, 0.1), w_v5=(0.78, 0.49, 1), w_usb=(0.23, 0.53, 1), w_step=(0.18, 0.78, 0.33), w_sig=(0.56, 0.89, 1), w_probe=(0.2, 0.2, 0.22), w_bus=(0.95, 0.3, 0.7))
WP = cq.Workplane

def box(sx, sy, sz, c=(0, 0, 0), f=0, sel=None):
    b = WP('XY').box(sx, sy, sz)
    if f:
        try: b = (b.edges(sel) if sel else b.edges()).fillet(f)
        except Exception: pass
    return b.translate(c)

def cyl(r, h, c=(0, 0, 0), axis='Z'):
    return WP({'Z': 'XY', 'Y': 'XZ', 'X': 'YZ'}[axis]).circle(r).extrude(h / 2, both=True).translate(c)

def tube(ro, ri, h, c=(0, 0, 0), axis='Z'):
    return WP({'Z': 'XY', 'Y': 'XZ', 'X': 'YZ'}[axis]).circle(ro).circle(ri).extrude(h / 2, both=True).translate(c)

def L(pos=(0, 0, 0), x=(1, 0, 0), z=(0, 0, 1)):
    """Placement: local X points along x, local Z along z."""
    return cq.Location(cq.Plane(origin=pos, xDir=x, normal=z))

@functools.lru_cache(None)
def tslot_profile(n=1):
    """20 mm T-slot section, n cells stacked along the sketch Y: 6.2 mm slot mouths, 8.4 mm cavities, 4.2 mm core holes."""
    s = WP('XY').rect(20, 20 * n).extrude(1)
    try: s = s.edges('|Z').fillet(1.2)
    except Exception: pass
    def slot(cx, cy, nx, ny):                     # (cx, cy) is the point on the face, (nx, ny) the outward normal
        mouth = WP('XY').center(cx - nx * 0.9, cy - ny * 0.9).rect(6.2 if nx == 0 else 1.9, 6.2 if ny == 0 else 1.9).extrude(1)
        cav = WP('XY').center(cx - nx * 3.4, cy - ny * 3.4).rect(8.4 if nx == 0 else 3.2, 8.4 if ny == 0 else 3.2).extrude(1)
        return mouth.union(cav)
    cut = None
    for k in range(n):
        yc = (k - (n - 1) / 2) * 20
        for sx in (-1, 1):
            c1 = slot(sx * 10, yc, sx, 0); cut = c1 if cut is None else cut.union(c1)
        cut = cut.union(WP('XY').center(0, yc).circle(2.1).extrude(1))
    for sy in (-1, 1): cut = cut.union(slot(0, sy * n * 10, 0, sy))
    return s.cut(cut).faces('<Z').val()

def extrusion(length, n=1):
    """T-slot extrusion along local Z, centred. n=2 is a 20 x 40 section with the 40 along local Y."""
    f = tslot_profile(n)
    return WP('XY').add(cq.Solid.extrudeLinear(f, cq.Vector(0, 0, length)).translate((0, 0, -length / 2)))

@functools.lru_cache(None)
def shcs(d=3, length=8):
    """Socket head cap screw, head on top at local Z >= 0, shank going down."""
    h = WP('XY').circle(d * 0.85).extrude(d).faces('>Z').workplane().polygon(6, d * 0.95).cutBlind(-d * 0.55)
    return h.union(WP('XY').circle(d / 2).extrude(-length))

@functools.lru_cache(None)
def corner_bracket():
    """Cast 20 mm corner bracket: legs along local +X and +Z from the inside corner, 18 wide in Y."""
    b = box(20, 18, 3, (10, 0, 1.5)).union(box(3, 18, 20, (1.5, 0, 10)))
    rib = WP('XZ').polyline([(3, 3), (18, 3), (3, 18)]).close().extrude(1.5, both=True)
    b = b.union(rib.translate((0, 7, 0))).union(rib.translate((0, -7, 0)))
    return b.cut(cyl(2.7, 10, (11, 0, 1.5))).cut(cyl(2.7, 10, (1.5, 0, 11), 'X'))

@functools.lru_cache(None)
def nema17(body=40):
    """NEMA 17 stepper, 42.3 mm square (pub). Mounting face at Z=0, shaft up, body below."""
    cap = lambda z: box(42.3, 42.3, 9, (0, 0, z)).edges('|Z').chamfer(4.5)
    top = cap(-4.5)
    for sx in (-1, 1):
        for sy in (-1, 1): top = top.cut(cyl(1.5, 10, (sx * 15.5, sy * 15.5, -2)))
    caps = top.union(cap(-body + 4.5))
    stack = box(41.6, 41.6, body - 18, (0, 0, -body / 2)).edges('|Z').chamfer(5.5)
    shaft = cyl(11, 2, (0, 0, 1)).union(cyl(2.5, 22, (0, 0, 13)).cut(box(5, 2, 16, (0, 2.9, 16))))
    conn = box(16, 5, 7, (0, 23, -body + 5))
    return [(caps, 'caps', 'alu'), (stack, 'stack', 'motor'), (shaft, 'shaft', 'steel'), (conn, 'connector', 'white')]

@functools.lru_cache(None)
def gt2_pulley():
    """GT2 20 tooth pulley, bore along Z, teeth band centred at Z=0."""
    p = cyl(6.1, 7, (0, 0, 0)).union(cyl(8, 1, (0, 0, 4))).union(cyl(8, 1, (0, 0, -4))).union(cyl(8, 6, (0, 0, -7.5)))
    return [(p.cut(cyl(2.5, 30)), 'pulley', 'alu')]

@functools.lru_cache(None)
def idler():
    p = cyl(6.1, 7).union(cyl(8, 1, (0, 0, 4))).union(cyl(8, 1, (0, 0, -4))).cut(cyl(1.5, 20))
    return [(p, 'idler', 'alu')]

@functools.lru_cache(None)
def vwheel():
    """V-slot wheel, 23.9 mm diameter, axis Z."""
    prof = WP('XZ').polyline([(5, -5.1), (9.8, -5.1), (11.95, -2.9), (11.95, 2.9), (9.8, 5.1), (5, 5.1)]).close().revolve(360, (0, 0, 0), (0, 1, 0))
    return [(prof, 'wheel', 'black'), (tube(5, 2.6, 10.2), 'bearing', 'steel')]

@functools.lru_cache(None)
def servo():
    """SunFounder SF3218MG class servo, 40 x 20 x 40.5 mm body (pub). Output shaft at the origin along +Z, body below, offset +10 in X."""
    low = box(40, 20, 12, (10, 0, -38.5), 1, '|Z'); mid = box(40, 20, 17, (10, 0, -24), 0.6, '|Z')
    up = box(40, 20, 11.5, (10, 0, -9.75), 1, '|Z').union(cyl(9.5, 4, (0, 0, -2)))
    ears = box(54.5, 20, 2.5, (10, 0, -11))
    for sx in (-14.75, 34.75):
        for sy in (-5, 5): ears = ears.cut(cyl(2.2, 6, (sx, sy, -11)))
    shaft = cyl(3, 4.5, (0, 0, 2.25)); lead = box(4, 7, 3, (31, 0, -35))
    return [(low.union(up).union(ears), 'case', 'servo'), (mid, 'mid_case', 'alu'), (shaft, 'spline', 'brass'), (lead, 'lead_exit', 'black')]

@functools.lru_cache(None)
def servo_horn():
    """Round metal horn, sits on the spline at Z 2.8 to 5.2."""
    h = cyl(11, 2.4, (0, 0, 4)).union(cyl(4.5, 4.2, (0, 0, 3.1)))
    for a in range(0, 360, 60): h = h.cut(cyl(1.1, 6, (8 * math.cos(math.radians(a)), 8 * math.sin(math.radians(a)), 4)))
    return [(h.cut(cyl(1.5, 10, (0, 0, 4))), 'horn', 'alu')]

@functools.lru_cache(None)
def d405():
    """RealSense D405, 42 x 42 x 23 mm (pub). Looks along local -Y."""
    b = box(42, 23, 42, (0, 0, 0), 4, '|Y').cut(box(36, 2, 16, (0, -11.5, 2))).cut(box(9.5, 6, 3.6, (0, 11.5, -12)))
    win = box(36, 0.8, 16, (0, -10.2, 2)); lens = cyl(4.2, 1.6, (-9, -10.6, 2), 'Y').union(cyl(4.2, 1.6, (9, -10.6, 2), 'Y'))
    return [(b, 'body', 'alu'), (win, 'window', 'glass'), (lens, 'imagers', 'lens')]

@functools.lru_cache(None)
def jetson():
    """Jetson Orin Nano developer kit, 100 x 79 x 21 mm (pub). Board lies in XY, connectors along the +Y edge."""
    pcb = box(100, 79, 1.6, (0, 0, 0.8))
    for sx in (-1, 1):
        for sy in (-1, 1): pcb = pcb.cut(cyl(1.4, 5, (sx * 46, sy * 35.5, 0.8)))
    mod = box(69.6, 45, 1.2, (-8, -8, 6.6)); slot = box(72, 6, 5, (-8, 17, 4.1))
    hs = box(60, 44, 3, (-8, -8, 8.7))
    for i in range(14): hs = hs.union(box(1.2, 44, 10, (-36.5 + i * 4.4, -8, 15.2)))
    hs = hs.cut(cyl(19, 12, (-8, -8, 16.2))); fan = cyl(18.5, 8, (-8, -8, 14.2)).cut(cyl(5, 10, (-8, -8, 16)))
    conn = box(14.5, 17.5, 15.6, (-36, 31.5, 9.4)).union(box(14.5, 17.5, 15.6, (-20, 31.5, 9.4))).union(box(16, 21.5, 13.5, (-2, 29.5, 8.35))).union(box(18, 9, 7, (16.5, 35.5, 5.1))).union(box(9, 7.4, 3.2, (30, 36, 3.2)))
    jack = box(9, 14, 11, (42, 32.5, 7.1)); hdr = box(5, 51, 8.5, (46.5, -9, 5.85))
    return [(pcb, 'carrier_board', 'pcb_black'), (mod.union(slot), 'module', 'pcb'), (hs, 'heatsink', 'alu'), (fan, 'fan', 'black'), (conn, 'io_connectors', 'steel'), (jack, 'dc_jack', 'black'), (hdr, 'header_40pin', 'black')]

@functools.lru_cache(None)
def psu():
    """Mean Well LRS-350-24 class supply, 215 x 115 x 30 mm (pub). Lies in XZ against a wall at Y=0, terminals at -X."""
    case = box(215, 30, 115, (0, 15, 0)).cut(box(211, 28, 111, (0, 15, 0))).cut(box(26, 26, 104, (-96, 18, 0)))
    slots = WP('XZ').rarray(16, 9, 9, 9).rect(11, 3.2).extrude(-4).translate((14, 31, 0))
    case = case.cut(slots)
    inner = box(180, 20, 104, (12, 13, 0)); tb = box(18, 16, 98, (-96, 10, 0))
    scr = None
    for i in range(9):
        s = cyl(3, 3, (-96, 19, -40 + i * 10), 'Y'); scr = s if scr is None else scr.union(s)
    return [(case, 'case', 'alu'), (inner, 'internals', 'dark'), (tb, 'terminal_block', 'black'), (scr, 'terminal_screws', 'steel')]

def _pcb(w, h, col, name, hole=1.3, inset=2.5):
    b = box(w, h, 1.6, (0, 0, 0.8))
    for sx in (-1, 1):
        for sy in (-1, 1): b = b.cut(cyl(hole, 5, (sx * (w / 2 - inset), sy * (h / 2 - inset), 0.8)))
    return (b, name, col)

@functools.lru_cache(None)
def teensy40():
    """Teensy 4.0, 35.6 x 17.8 mm (pub)."""
    return [(box(35.6, 17.8, 1.6, (0, 0, 0.8)), 'board', 'pcb'), (box(10, 10, 1.2, (2, 0, 2.2)), 'mcu', 'black'), (box(5.6, 7.6, 2.6, (-15.4, 0, 2.9)), 'usb_micro', 'steel'),
            (box(34, 2.4, 2.5, (0, 7.6, -1.25)).union(box(34, 2.4, 2.5, (0, -7.6, -1.25))), 'pin_headers', 'black')]

@functools.lru_cache(None)
def pca9685():
    """Adafruit PCA9685 servo driver, 62.5 x 25.4 mm (pub)."""
    hdr = box(41, 7.6, 8.5, (0, -8, 5.85)); pins = box(41, 0.7, 6, (0, -8, 10.5)).union(box(41, 0.7, 6, (0, -5.5, 10.5))).union(box(41, 0.7, 6, (0, -10.5, 10.5)))
    return [_pcb(62.5, 25.4, 'pcb_blue', 'board'), (hdr, 'servo_headers', 'black'), (pins, 'header_pins', 'gold'), (box(10, 7.6, 10, (0, 8, 6.6)), 'power_terminal', 'pcb_blue'),
            (cyl(4, 11, (20, 6, 7.1)), 'capacitor', 'dark'), (box(7, 9.7, 1.6, (-18, 5, 2.4)), 'driver_chip', 'black')]

@functools.lru_cache(None)
def hx711():
    return [_pcb(24, 31, 'pcb_red', 'board', 1.1, 2.2), (box(4, 10, 1.6, (0, 2, 2.4)), 'chip', 'black'), (box(12, 2.5, 8.5, (0, -12, 5.85)).union(box(10, 2.5, 8.5, (0, 12, 5.85))), 'headers', 'black')]

@functools.lru_cache(None)
def buck_small():
    """Pololu D36V50Fx, 25.4 x 25.4 x 9.5 mm (pub)."""
    return [_pcb(25.4, 25.4, 'pcb', 'board', 1.1, 2.2), (box(10.5, 10.5, 5, (2, 2, 4.1)), 'inductor', 'dark'), (box(6, 4, 2.5, (-7, -6, 2.85)).union(box(6, 4, 2.5, (-7, 6, 2.85))), 'capacitors', 'gold'), (box(4, 4, 1.2, (6, -8, 2.2)), 'regulator_ic', 'black')]

@functools.lru_cache(None)
def buck_large():
    """Pololu D24V150Fx, 43.2 x 31.8 mm (pub)."""
    return [_pcb(43.2, 31.8, 'pcb', 'board', 1.6, 3), (box(15, 15, 8, (2, 2, 5.6)), 'inductor', 'dark'), (box(10, 8, 10, (-15, 7, 6.6)).union(box(10, 8, 10, (15, -7, 6.6))), 'screw_terminals', 'pcb_blue'),
            (cyl(4, 9, (-12, -8, 6.1)).union(cyl(4, 9, (13, 9, 6.1))), 'capacitors', 'dark')]

@functools.lru_cache(None)
def bno085():
    """Adafruit BNO085 breakout, 25.4 x 17.8 mm (pub)."""
    return [_pcb(25.4, 17.8, 'pcb_black', 'board', 1.25, 2.5), (box(5.2, 3.8, 1.1, (0, 0, 2.15)), 'imu_chip', 'black'), (box(4.5, 6, 3, (-9.5, 0, 3.1)).union(box(4.5, 6, 3, (9.5, 0, 3.1))), 'stemma_connectors', 'white')]

@functools.lru_cache(None)
def mosfet():
    return [_pcb(17.8, 25.4, 'pcb_black', 'board', 1.1, 2.2), (box(7.6, 7.6, 10, (0, 7, 6.6)), 'load_terminal', 'pcb_blue'), (box(8, 5, 6, (0, -9, 4.6)), 'jst_input', 'white'), (box(3, 3, 1.2, (0, -1, 2.2)), 'mosfet', 'black')]

@functools.lru_cache(None)
def fuse_block():
    b = box(36, 44, 12, (0, 0, 6), 1.5, '|Z'); fz = None
    for i in range(4):
        f = box(5, 16, 9, (-12 + i * 8, 0, 16.5)); fz = f if fz is None else fz.union(f)
    studs = cyl(2.5, 6, (0, 18, 15)).union(cyl(2.5, 6, (0, -18, 15)))
    return [(b, 'base', 'black'), (fz, 'blade_fuses', 'red'), (studs, 'studs', 'brass')]

@functools.lru_cache(None)
def usb_hub():
    """Powered 7-port USB 3 hub (est), 100 x 32 x 20 mm, long side along local X."""
    b = box(100, 32, 20, (0, 0, 10), 3, '|Z'); p = None
    for i in range(7):
        q = box(13, 6, 5.5, (-39 + i * 13, -14, 10)); p = q if p is None else p.union(q)
    return [(b.cut(p), 'case', 'black'), (p.translate((0, 2.5, 0)), 'ports', 'steel'), (cyl(3.2, 6, (50, 0, 10), 'X'), 'dc_jack', 'steel')]

@functools.lru_cache(None)
def mains_inlet():
    """IEC C14 inlet with rocker switch and fuse drawer (est), flange 48 x 60 mm, faces local +Z."""
    f = box(48, 60, 3, (0, 0, 1.5), 3, '|Z'); body = box(40, 52, 30, (0, 0, -15))
    f = f.cut(box(24, 16.5, 12, (0, -14, 0)))
    pins = box(2, 4, 8, (-7, -14, -2)).union(box(2, 4, 8, (0, -11.5, -2))).union(box(2, 4, 8, (7, -14, -2)))
    return [(f.union(body.cut(box(24, 16.5, 16, (0, -14, -6)))), 'housing', 'black'), (pins, 'pins', 'brass'), (box(22, 14, 6, (0, 14, 4), 1.5), 'rocker', 'red'), (box(22, 7, 2, (0, 0.5, 3.2)), 'fuse_drawer', 'dark')]

@functools.lru_cache(None)
def controller_box():
    """Motion controller in a vented case (est 110 x 85 x 36), board 100 x 70 inside."""
    c = box(110, 85, 36, (0, 0, 18), 3, '|Z').cut(box(106, 81, 32, (0, 0, 18)))
    c = c.cut(WP('XY').rarray(9, 1, 9, 1).rect(4, 60).extrude(6).translate((0, 0, 32))).cut(box(60, 6, 12, (0, 42, 14)))
    pcb = box(100, 70, 1.6, (0, 0, 8)); drv = None
    for i in range(4):
        d = box(9, 12, 8, (-36 + i * 14, 12, 12.8)); drv = d if drv is None else drv.union(d)
    term = box(50, 8, 10, (0, 30, 13.8)); mcu = box(14, 14, 1.4, (10, -12, 9.5))
    return [(c, 'case', 'dark'), (pcb, 'board', 'pcb'), (drv, 'stepper_driver_heatsinks', 'alu'), (term, 'terminals', 'pcb_blue'), (mcu, 'mcu', 'black')]

@functools.lru_cache(None)
def touchscreen():
    """7 inch HDMI capacitive touchscreen in its case (est outline 190 x 122 x 14). Screen faces local -Y, long side along X."""
    case = box(190, 13, 122, (0, 6.5, 0), 5, '|Y'); glass = box(186, 1.2, 118, (0, -0.6, 0), 4, '|Y'); act = box(154.2, 0.3, 85.9, (0, -1.3, 2))
    ports = box(15, 6, 11, (60, 9, -61)).union(box(8, 3, 6, (38, 9, -61))).union(box(8, 3, 6, (24, 9, -61)))
    return [(case, 'case', 'black'), (glass, 'cover_glass', 'dark'), (act, 'active_area', 'glass'), (ports, 'ports', 'steel')]

@functools.lru_cache(None)
def phone():
    """Phone outline (est 147 x 72 x 8). Screen faces local -Y."""
    b = box(72, 8, 147, (0, 0, 0), 9, '|Y'); scr = box(66, 0.3, 141, (0, -4.1, 0), 7, '|Y'); cam = box(30, 2, 30, (-16, 5, 50), 6, '|Y')
    return [(b, 'body', 'dark'), (scr, 'screen', 'glass'), (cam, 'camera_bump', 'black')]

@functools.lru_cache(None)
def estop():
    """22 mm emergency stop (pub hole size). Panel surface at local Y=0, button toward -Y, contact block behind."""
    base = tube(21, 11, 9, (0, -4.5, 0), 'Y'); stem = cyl(11, 16, (0, -8, 0), 'Y')
    cap = WP('XZ').polyline([(0, 16), (20, 16), (20, 24), (14, 30), (0, 31)]).close().revolve(360, (0, 0, 0), (0, 1, 0))
    cap = cap.rotate((0, 0, 0), (1, 0, 0), 90).rotate((0, 0, 0), (0, 0, 1), 0)
    nut = tube(14, 11, 5, (0, 5.5, 0), 'Y'); blk = box(30, 30, 32, (0, 26, 0), 2, '|Y'); scr = cyl(2.2, 3, (-8, 43, 8), 'Y').union(cyl(2.2, 3, (8, 43, 8), 'Y')).union(cyl(2.2, 3, (-8, 43, -8), 'Y')).union(cyl(2.2, 3, (8, 43, -8), 'Y'))
    return [(base, 'legend_ring', 'yellow'), (stem, 'stem', 'red'), (cap, 'mushroom', 'red'), (nut, 'lock_nut', 'black'), (blk, 'contact_block', 'dark'), (scr, 'terminals', 'brass')]

@functools.lru_cache(None)
def load_cell():
    """TAL220B 5 kg bar, 80 x 12.7 x 12.7 mm (pub), long side along X."""
    b = box(80, 12.7, 12.7).cut(cyl(4.6, 14, (-5.5, 0, 0), 'Y')).cut(cyl(4.6, 14, (5.5, 0, 0), 'Y')).cut(box(11, 14, 3, (0, 0, 0)))
    for x in (-35, -20, 20, 35): b = b.cut(cyl(2.1, 14, (x, 0, 0)))
    return [(b, 'bar', 'alu'), (box(22, 12.9, 8, (0, 0, 0)).cut(box(24, 11.5, 9)), 'sealant', 'white')]

@functools.lru_cache(None)
def solenoid():
    """Adafruit 413 class push-pull solenoid, 10 mm throw (pub); frame 26 x 24 x 32 (est). Plunger axis Z, pushes toward -Z."""
    fr = box(26, 24, 32).cut(box(22, 26, 28)).cut(cyl(2.6, 40)); coil = tube(10, 3, 26); bob = tube(11, 2.6, 1.5, (0, 0, 13.5)).union(tube(11, 2.6, 1.5, (0, 0, -13.5)))
    return [(fr, 'frame', 'steel'), (coil, 'coil', 'copper'), (bob, 'bobbin', 'black')]

@functools.lru_cache(None)
def linear_actuator():
    """Actuonix L12-30-50-6-R micro linear servo: 30 mm stroke, 82 mm closed length hole to hole (pub); 18 x 15 mm body section (est).
    Rod end at the origin, rod and body rising along +Z. Drawn retracted."""
    body = box(18, 15, 48, (0, 0, 44), 1.5, '|Z'); shaft_house = box(11, 11, 12, (0, 0, 14), 1, '|Z'); cap = box(18, 15, 5, (0, 0, 70.5), 1.5, '|Z').union(box(6, 15, 9, (0, 0, 77.5)).cut(cyl(2, 20, (0, 0, 82), 'Y')))
    rod = cyl(3, 10, (0, 0, 5)).union(box(6, 6, 6, (0, 0, 0)).cut(cyl(2, 10, (0, 0, 0), 'Y')))
    return [(body.union(shaft_house), 'body', 'dark'), (cap, 'end_cap', 'black'), (rod, 'rod', 'steel'), (box(5, 3, 6, (6, 0, 71)), 'lead_exit', 'black')]

@functools.lru_cache(None)
def st3215():
    """Waveshare ST3215 serial bus servo: 12-bit magnetic encoder, 30 kg.cm at 12 V, 89 g (pub). Body 45.2 x 24.7 x 32 mm (est).
    Output shaft at the origin along +Z, body top face at Z=-4, body running toward +X, bus sockets on the far end."""
    body = box(45.2, 24.7, 32, (12.1, 0, -20), 2, '|Z'); boss = cyl(7, 6.8, (0, 0, -0.6)); rear = cyl(8, 2.5, (0, 0, -37.25))
    ports = box(3, 7, 5, (35.6, 5, -22)).union(box(3, 7, 5, (35.6, -5, -22)))
    return [(body, 'case', 'servo'), (boss, 'output_boss', 'alu'), (rear, 'idle_horn', 'alu'), (ports, 'bus_sockets', 'white')]

@functools.lru_cache(None)
def st3215_horn():
    h = cyl(10.5, 3, (0, 0, 4.3))
    for a in range(0, 360, 90): h = h.cut(cyl(1.1, 6, (7 * math.cos(math.radians(a)), 7 * math.sin(math.radians(a)), 4.3)))
    return [(h.cut(cyl(1.5, 10, (0, 0, 4.3))), 'horn', 'alu')]

@functools.lru_cache(None)
def bus_adapter():
    """Waveshare Bus Servo Adapter (A), 42 x 33 mm (pub)."""
    return [_pcb(42, 33, 'pcb_blue', 'board', 1.25, 2.5), (box(9, 7.4, 3.2, (-16, 0, 3.2)), 'usb_c', 'steel'), (box(10, 7.6, 10, (14, 9, 6.6)), 'power_terminal', 'pcb'),
            (box(7, 5, 6, (8, -11, 4.6)).union(box(7, 5, 6, (-2, -11, 4.6))), 'servo_sockets', 'white'), (box(5, 5, 1.2, (-3, 4, 2.2)), 'uart_chip', 'black')]

@functools.lru_cache(None)
def buck_tiny():
    """Pololu D36V28Fx, 17.8 x 20.3 x 8.8 mm (pub)."""
    return [(box(17.8, 20.3, 1.6, (0, 0, 0.8)), 'board', 'pcb'), (box(7, 7, 4.5, (1, 1, 3.85)), 'inductor', 'dark'), (box(3, 3, 1.2, (-5, -6, 2.2)), 'regulator_ic', 'black')]

@functools.lru_cache(None)
def mgn12h():
    """MGN12H linear carriage: 27 wide, 45.4 long, 13 high on a 12 x 8 rail (pub). Travel along Z; the rail side is +Y, the mounting face -Y."""
    b = box(27, 10, 39.4).cut(box(12.4, 5.2, 50, (0, 2.5, 0)))
    for a in (-1, 1):
        for c in (-1, 1): b = b.cut(cyl(1.5, 6, (a * 10, -3, c * 10), 'Y'))
    caps = box(27, 10, 3, (0, 0, 21.2)).union(box(27, 10, 3, (0, 0, -21.2))).cut(box(12.4, 5.2, 50, (0, 2.5, 0)))
    return [(b, 'block', 'steel'), (caps, 'end_caps', 'red')]

@functools.lru_cache(None)
def limit_switch():
    """Micro switch with roller lever, 20 x 6.4 x 10 mm body, lever on +Z."""
    b = box(20, 6.4, 10).cut(cyl(1.2, 8, (-4.75, 0, -2.5), 'Y')).cut(cyl(1.2, 8, (4.75, 0, -2.5), 'Y'))
    lev = box(16, 4, 0.5, (1, 0, 7.2)).rotate((-7, 0, 5), (-7, 1, 5), -10); rol = cyl(2.4, 4, (8.5, 0, 10.3), 'Y'); t = box(0.6, 3, 4, (-8, 0, -7)).union(box(0.6, 3, 4, (0, 0, -7))).union(box(0.6, 3, 4, (8, 0, -7)))
    return [(b, 'body', 'black'), (lev, 'lever', 'steel'), (rol, 'roller', 'white'), (t, 'terminals', 'brass')]

@functools.lru_cache(None)
def grommet():
    """Rubber grommet for a 16 mm hole in a 3 mm panel, axis Z, panel mid-plane at Z=0."""
    return [(tube(11, 6, 2, (0, 0, 2.5)).union(tube(11, 6, 2, (0, 0, -2.5))).union(tube(8, 6, 3)), 'grommet', 'rubber')]

def probe_butterfly(Lp=152, w=52, t=37):
    """Butterfly iQ3 outline, 152 x 52 x 37 mm (pub). Face at Z=0, body rising along +Z."""
    secs = [(0, w * 0.8, t * 0.62, 3), (9, w, t * 0.78, 6), (34, w, t, 9), (60, w * 0.87, t * 0.92, 10), (Lp - 24, w * 0.85, t * 0.9, 10), (Lp - 8, w * 0.72, t * 0.78, 9), (Lp, w * 0.42, t * 0.5, 6)]
    wp = None
    for z, a, b, r in secs:
        s = WP('XY').workplane(offset=z).rect(a, b)
        wp = s if wp is None else wp.workplane(offset=z - lastz).rect(a, b)
        lastz = z
    body = wp.loft(combine=True)
    try: body = body.edges('|Z').fillet(4)
    except Exception: pass
    lens = box(w * 0.74, t * 0.5, 1.2, (0, 0, -0.6), 2.5, '|Z'); strain = cyl(5.5, 22, (0, 0, Lp + 9))
    return [(body, 'body', 'probe'), (lens, 'lens', 'lens'), (strain, 'strain_relief', 'black')]

def probe_vscan(Lp=129, w=39, t=28):
    """Vscan Extend dual probe outline, 129 x 39 x 28 mm (pub). One transducer at each end."""
    secs = [(0, w * 0.76, t * 0.7), (8, w, t), (26, w, t), (40, w * 0.82, t * 0.84), (Lp - 40, w * 0.82, t * 0.84), (Lp - 26, w, t), (Lp - 8, w, t), (Lp, w * 0.76, t * 0.7)]
    wp = None
    for z, a, b in secs:
        wp = WP('XY').workplane(offset=z).rect(a, b) if wp is None else wp.workplane(offset=z - lastz).rect(a, b)
        lastz = z
    body = wp.loft(combine=True)
    try: body = body.edges('|Z').fillet(4)
    except Exception: pass
    lens = box(w * 0.7, t * 0.55, 1.2, (0, 0, -0.6), 2.5, '|Z').union(box(w * 0.7, t * 0.55, 1.2, (0, 0, Lp + 0.6), 2.5, '|Z'))
    return [(body, 'body', 'white'), (lens, 'lenses', 'lens'), (cyl(5, 20, (0, t / 2 + 8, Lp - 34), 'Y'), 'strain_relief', 'black')]

def _dense(pts):
    P = [cq.Vector(*p) for p in pts]; d = [P[0]]
    for a, b in zip(P, P[1:]):
        v = b - a; n = v.Length
        if n < 0.5: continue
        lead = min(10, n * 0.3)
        if n > 8: d += [a + v * (lead / n), b - v * (lead / n)]
        d.append(b)
    return d

def _capsules(d, r):
    out = None
    for a, b in zip(d, d[1:]):
        v = b - a
        if v.Length < 0.3: continue
        c = cq.Solid.makeCylinder(r, v.Length, a, v); sph = cq.Solid.makeSphere(r, b)
        out = [c, sph] if out is None else out + [c, sph]
    return WP('XY').add(cq.Compound.makeCompound(out))

def wire(pts, r):
    """Round cable through way-points, hugging each straight run and rounding the corners. Falls back to straight segments with ball joints if the smooth sweep fails."""
    d = _dense(pts)
    for frenet in (False, True):
        try:
            path = WP('XY').spline([p.toTuple() for p in d]); t = (d[1] - d[0]).normalized()
            s = WP(cq.Plane(origin=d[0].toTuple(), normal=t.toTuple())).circle(r).sweep(path, isFrenet=frenet)
            ln = sum((q - p).Length for p, q in zip(d, d[1:])); ratio = s.val().Volume() / (math.pi * r * r * ln)
            if s.val().isValid() and 0.9 < ratio < 1.06: return s          # a lumpy or folded sweep has the wrong volume
        except Exception: pass
    return _capsules(d, r)
